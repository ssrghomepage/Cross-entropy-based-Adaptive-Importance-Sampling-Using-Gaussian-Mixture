%Main CEAISGM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Main file of Cross Entropy Based Adaptive Importance Sampling Using    %
%% Gaussian Mixtures (CE-AIS-GM) Algorithm by Nolan Kurtz and Junho Song, %
%% Department of Civil and Environmental Engineering,                     %
%% Univerisity of Illinois at Urbana-Champaign, Urbana, IL 61820, USA.    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all;

%option of whether there is a output file
while 1
    fprintf('Please enter the name of the output Excel file (with no ".xls" or ".xlsx").\n');
    fprintf('Press the "Enter" key if you do not want any output file.\n\n');
    outxls_name = input('Output file name: ','s');
    
    if isempty(outxls_name) == 1
        outxls = 0;
        clear outxls_name;
        break;
    else
        outxls = 1;
        break;
    end
end

%initializing parameters
if strcmp(ceaisgmopt.default,'yes')
    input.N_rvs 	= size(probdata.marg,1);
    input.N_dps 	= 20;
    input.N_multi 	= 1000;
    input.g_roh 	= 0.1;
    input.R_factor 	= 0.5;
    input.cov_level = 0.05;
elseif strcmp(ceaisgmopt.default,'no')
    input.N_rvs 	= size(probdata.marg,1);
    input.N_dps 	= ceaisgmopt.N_search;
    input.N_multi 	= ceaisgmopt.N_presam;
    input.g_roh 	= 0.1;
    input.R_factor 	= ceaisgmopt.R_factor;
    input.cov_level = ceaisgmopt.target_cov;
else
    disp('Incorrect CEAISGM inputs, terminate program.')
    return;
end

%Using Nataf Distribution Model
R_mod = mod_corr(probdata, probdata.correlation);
Lo = chol(R_mod, 'lower');


%--CE algorithm--
disp('Main CE-AIS-GM');
fprintf('*01.Initializing');
fprintf('.'),pause(0.25);
fprintf('.'),pause(0.25);
fprintf('.\n'),pause(0.4);
fprintf('\t- Number of RVs: %i\n\t- Number of search points: %i\n',...
    input.N_rvs, input.N_dps);
fprintf('\t- Multi-gussian algorithm presample size: %i\n\t- Convergence Level of IS: %i%%\n\n',...
    input.N_multi, 100*input.cov_level);

%single gaussian algorithm
fprintf('*02.Running single gaussian algorithm');
fprintf('.'),pause(0.25);
fprintf('.'),pause(0.25);
fprintf('.\n'),pause(0.25);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:3
    output = A1_single_update(input,probdata,Lo,gfundata,system_data);
    temp_sf(i,1) = output.sf;
    temp(i).mu_SG = output.mu_cur;
    temp(i).R_factor = 1;
    RRR(i,1) = A2_radius(temp(i));
end
[aaa,bbb] = sort(RRR,'descend');
input.mu_SG = temp(bbb(2)).mu_SG;
input.sf = temp_sf(bbb(2));
clear temp temp_sf RRR output aaa bbb i;    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%compute scaled radius & initial point for GM
fprintf('*03.Computing initial points for gaussian mixtures');
fprintf('.'),pause(0.25);
fprintf('.'),pause(0.25);
fprintf('.\n'),pause(0.4);
input.radius = A2_radius(input);
input.mu_init_GM = A3_GM_dps(input);
fprintf('\t- %i%% of radius obtained from step 02\n\t  is used to compute initial points.\n\n',...
    input.R_factor*100);

%multi-guassian algorithm
fprintf('*04.Running multi-gaussian algorithm');
fprintf('.'),pause(0.25);
fprintf('.'),pause(0.25);
fprintf('.\n'),pause(0.25);
[output] = A4_multi_update(input,probdata,Lo,gfundata,system_data);
input.mu_final = output.mu_cur;
input.sig_final = output.sig;
input.Pi_final = output.Pi_cur;
clear output;

%final important sampling
fprintf('*05.Final important sampling');
fprintf('.'),pause(0.25);
fprintf('.'),pause(0.25);
fprintf('.\n'),pause(0.25);
[output] = B1_final_IS(input,probdata,Lo,gfundata,system_data);

%printing output file (if applicable)
if outxls == 1
    OUT = {'CEAISGM PARAMETERS:',' ';'Default setting used?(yes/no)',ceaisgmopt.default;...
        'No. of search points',ceaisgmopt.N_search;'Pre-sample size',ceaisgmopt.N_presam;...
        'Radius length factor',ceaisgmopt.R_factor;'Target CoV',ceaisgmopt.target_cov;' ',' ';...
        'RESULTS OUTPUT:',' '; 'Probability of failure',output.Pf;...
        'Iterations used', output.num};
    xlswrite(outxls_name,OUT);
end


if outxls == 0
    fprintf('\n=END OF ANALYSIS=\n\n');
elseif outxls == 1
    fprintf('\n=END OF ANALYSIS, OUTPUT FILE IS AVAILABLE=\n\n');
end

clear Lo R_mod input outxls OUT